import streamlit as st

st.title("Aplikasi Utama")
st.write("Hello, World!")

if "Nabung" not in st.session_state:
    st.session_state['Nabung'] = []

st.write("State Nabung:", st.session_state['Nabung'])